package com.eloaca.adopet.core.ports.datastore

import com.eloaca.adopet.adapters.datastore.entity.AdocaoEntity
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface AdocaoRepository : JpaRepository<AdocaoEntity, Long> {

    fun countByTutorId(idTutor: Long) : Int

    fun existsByPetIdAndStatus(idPet: Long) : Int
}