package com.eloaca.adopet.core.ports.datastore

import com.eloaca.adopet.adapters.datastore.entity.TutorEntity
import org.springframework.data.jpa.repository.JpaRepository

interface TutorRepository : JpaRepository<TutorEntity, Long> {

}