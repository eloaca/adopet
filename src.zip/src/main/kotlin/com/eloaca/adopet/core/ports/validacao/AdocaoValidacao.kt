package com.eloaca.adopet.core.ports.validacao

interface AdocaoValidacao {

    fun validar()
}