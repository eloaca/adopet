package com.eloaca.adopet.core.exceptions

class AdocaoException(message: String?): RuntimeException(message)