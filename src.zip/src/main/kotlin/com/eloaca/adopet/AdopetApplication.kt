package com.eloaca.adopet

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class AdopetApplication

fun main(args: Array<String>) {
	runApplication<AdopetApplication>(*args)
}
