package com.eloaca.adopet.adapters.validacao

import com.eloaca.adopet.core.ports.datastore.AdocaoRepository
import com.eloaca.adopet.core.ports.validacao.AdocaoValidacao

class PetEmAdocaoValidacao(val repository: AdocaoRepository) : AdocaoValidacao {
    override fun validar() {
        repository.existsByPetIdAndStatus(1L)
        TODO("Not yet implemented")
    }
}