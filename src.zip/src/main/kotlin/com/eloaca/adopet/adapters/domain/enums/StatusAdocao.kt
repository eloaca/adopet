package com.eloaca.adopet.adapters.domain.enums

enum class StatusAdocao {

    ADOTADO,
    ADOCAO_EM_ANDAMENTO,
    DISPONIVEL,
    INDISPONIVEL
}