package com.eloaca.adopet.adapters.domain.enums

enum class TipoDocumento {

    RG,
    PASSAPORTE,
    CNPJ,
    CPF
}