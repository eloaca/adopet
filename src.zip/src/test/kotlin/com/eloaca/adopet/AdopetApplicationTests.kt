package com.eloaca.adopet

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AdopetApplicationTests {

	@Test
	fun contextLoads() {
	}

}
